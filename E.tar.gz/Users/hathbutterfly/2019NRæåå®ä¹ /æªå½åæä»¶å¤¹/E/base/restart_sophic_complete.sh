#!/bin/csh

set SOPHIC_NUB = `ps -ef | grep "deployment" | grep "sophic" | grep -v "grep" | awk ' {print   $2} ' | wc |awk '{print $1}'`
printf "sophic(deployment) nub:<%d>\n" $SOPHIC_NUB

set SOPHIC_START_NUB = `ps -ef | grep "sophic_start" | grep -v "grep" | awk ' {print   $2} ' | wc |awk '{print $1}'`
printf "sophic_start nub:<%d>\n" $SOPHIC_START_NUB

if($SOPHIC_NUB > 3)then
   echo "sophic_alive need stop"
   su - ems -c "/users/ems/sophic/deployment/bin/plat/sophic_stop y"
   set SOPHIC_NUB_AFTER = `ps -ef | grep "deployment" | grep "sophic" | grep -v "grep" | awk ' {print   $2} ' | wc |awk '{print $1}'`
   printf "sophic(deployment) nub:<%d> after sophic_stop\n" $SOPHIC_NUB_AFTER
   if($SOPHIC_NUB_AFTER > 2)then
	kill -9   `ps   -ef|grep   "deployment" | grep   "sophic" |grep -v "grep"|awk   ' {print   $2} '`
   else
        echo "sophic_stop clear"
   endif
   su - ems -c "/users/ems/sophic/deployment/bin/plat/sophic_stop y"
   if($SOPHIC_START_NUB > 0)then
	echo "kill sophic_start begin"
	kill -9   `ps   -ef|grep   "sophic_start" |grep -v "grep"|awk   ' {print   $2} '`
	echo "kill sophic_start end"
   else
	echo "sophic_start nub is 0, so no need kill"
   endif
   echo "sleep 1s"
   sleep 1s
   echo "begin run linux_sophic.sh"
   /users/ems/sophic/deployment/bin/base/linux_sophic.sh&
   echo "sleep 2s after linux_sophic.sh"
   sleep 2s
else
   echo "no need sophic_stop"
   set NET_DAEMON_NUB = `ps -ef | grep "net_daemon" | grep -v "grep" | awk ' {print   $2} ' | wc |awk '{print $1}'`
   printf "net_daemon nub:<%d>\n" $NET_DAEMON_NUB
   if($NET_DAEMON_NUB > 0)then
	kill -9   `ps   -ef|grep  "net_daemon"|grep -v "grep"|awk   ' {print   $2} '`
   else
        echo "net_daemon is 0, so no need kill"
   endif
   echo "sophic_alive need stop"
   su - ems -c "/users/ems/sophic/deployment/bin/plat/sophic_stop y"
   if($SOPHIC_START_NUB > 0)then
	echo "kill sophic_start begin"
	kill -9   `ps   -ef|grep   "sophic_start" |grep -v "grep"|awk   ' {print   $2} '`
	echo "kill sophic_start end"
   else
	echo "sophic_start nub is 0, so no need kill"
   endif
   echo "begin run linux_sophic.sh"
   /users/ems/sophic/deployment/bin/base/linux_sophic.sh&
   echo "sleep 2s after linux_sophic.sh"
   sleep 2s
endif