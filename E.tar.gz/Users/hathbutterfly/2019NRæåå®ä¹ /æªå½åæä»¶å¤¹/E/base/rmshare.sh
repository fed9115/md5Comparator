#!/bin/csh
rm -rf /users/ems/sophic/deployment/data/share/* 
rm -f /users/ems/sophic/deployment/data/net/shm/*

