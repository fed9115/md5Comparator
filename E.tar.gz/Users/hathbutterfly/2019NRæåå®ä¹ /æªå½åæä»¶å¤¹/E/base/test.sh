#!/bin/tcsh
source /users/ems/.cshrc
/users/ems/sophic/deployment/bin/mmi/drawgraph
